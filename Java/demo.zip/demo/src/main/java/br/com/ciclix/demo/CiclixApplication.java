package br.com.ciclix.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CiclixApplication {

	public static void main(String[] args) {
		SpringApplication.run(CiclixApplication.class, args);
	}

}
